


<div class="portfolio1">
     <div class="port-container">
    	<div class="designdiv">
    		<h1>wed design</h1>
    		<p>is simply dummy text of the printing and typesetting <br>
    		 industry.is simply dummy text of the printing <br>
    		  and typesetting industry.</p>
    		
    	</div>
    	<div class="brandingdiv">
    		<h1>branding</h1>
    		<p>is simply dummy text of the printing and typesetting <br>
    		 industry.is simply dummy text of the printing <br>
    		  and typesetting industry.</p>
    		
    	</div>
    	<div class="aderdisingdiv">
    		<h1>advertising</h1>
    		<p>is simply dummy text of the printing and typesetting <br>
    		 industry.is simply dummy text of the printing <br>
    		  and typesetting industry.</p>
    		
    	</div>
     </div>
    </div>
