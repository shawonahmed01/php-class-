



 <div class="div-pik">
     <div class="pik-container">
    	<div class="pik-1">
    		<img src="photo/Screenshot_4.png" alt="">
    		
    	</div>
    	<div class="pik-2">
    		<img src="photo/Screenshot_5.png" alt="">
    		
    	</div>
    	<div class="pik-3">
    		<img src="photo/Screenshot_3.png" alt="">
    		
    	</div>
     </div>
    </div>