


<div class="full-header">
		<div class="header-container">
			<div class="logo-area">
				<div class="logo">
					<img src="photo/amazon_png_31237.png" alt="">
					
				</div>
			</div>
			


			<div class="main-menu">
				<div class="menu">
					<ul>
						<li><a href="#" class="new-home">HOME</a></li>
						<li><a href="#">services</a></li>
						<li><a href="#">contact</a></li>
						<li><a href="#">services</a></li>
						<li><a href="#">about us</a></li>
					</ul>
				</div>
			</div>
		</div>		
	</div>