


  <section class="banewe">
     	<div class="mb-conatiner">
	  <div class="main-body">
	  	<div class="body-header">
	  	<h3>welcome to <br>
	  	 dynamic <br> 
	  	studio</h3>
	  	</div>
          <div class="peragraph-area">
          	<p>is simply dummy text of the printing and typesetting industry. <br>
          	 Lorem Ipsum has been the industry's standard dummy text ever since the <br>
          	 1500s, when an unknown printer took a galley of type and scrambled it to <br>
          	 make a type specimen book. It has survived not only five centuries, but <br>
          	  also the leap into electronic typesetting, remaining essentially <br>
          	  unchanged. It was popularised in </p>
          </div>

          <div class="for-button">
          	<button>search anything</button>
          </div>

	  </div>
	  </div>
	</section>