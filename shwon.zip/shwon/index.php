<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
	<link rel="stylesheet" href="css/websitecss.css">
</head>
<body>
	<?php include('component/body.php'); ?>
	<?php include('component/body1.php'); ?>
	<?php include('component/body2.php'); ?>
	<?php include('component/body3.php'); ?>
</body>
</html>